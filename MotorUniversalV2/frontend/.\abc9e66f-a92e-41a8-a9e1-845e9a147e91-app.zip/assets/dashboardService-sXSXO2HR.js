import{d as a}from"./index-C5BZvRQ4.js";const r={getDashboard:async()=>(await a.get("/users/me/dashboard")).data};export{r as d};
