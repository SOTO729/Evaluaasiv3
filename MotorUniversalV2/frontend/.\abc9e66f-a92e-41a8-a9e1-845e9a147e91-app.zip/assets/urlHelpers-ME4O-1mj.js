function t(e){if(!e)return!1;try{return new URL(e,"https://placeholder.invalid").hostname.endsWith(".blob.core.windows.net")}catch{return!1}}export{t as i};
