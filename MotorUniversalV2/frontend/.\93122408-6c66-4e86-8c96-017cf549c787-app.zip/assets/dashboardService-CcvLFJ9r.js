import{b as a}from"./index-CN_hpHs6.js";const r={getDashboard:async()=>(await a.get("/users/me/dashboard")).data};export{r as d};
