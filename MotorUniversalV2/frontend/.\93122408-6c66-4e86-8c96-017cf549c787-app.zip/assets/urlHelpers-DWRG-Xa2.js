function n(e){return e?e.includes("blob.core.windows.net")||e.includes("azurefd.net"):!1}export{n as i};
