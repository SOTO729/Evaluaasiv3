import{j as t}from"./query-vendor-DOrzA5ok.js";const s={indigo:{on:"bg-indigo-600",ring:"focus:ring-indigo-400"},blue:{on:"bg-blue-600",ring:"focus:ring-blue-400"},green:{on:"bg-green-600",ring:"focus:ring-green-400"},purple:{on:"bg-purple-600",ring:"focus:ring-purple-400"},amber:{on:"bg-amber-500",ring:"focus:ring-amber-400"},emerald:{on:"bg-emerald-600",ring:"focus:ring-emerald-400"},cyan:{on:"bg-cyan-600",ring:"focus:ring-cyan-400"},rose:{on:"bg-rose-600",ring:"focus:ring-rose-400"}};function u({checked:i,onChange:a,disabled:o=!1,size:g="md",colorScheme:c="indigo"}){const e=s[c]||s.indigo,n=!!i,r=g==="sm"?{track:"w-9 h-5",thumb:"h-3.5 w-3.5",translate:"translate-x-4",offset:"translate-x-0.5"}:{track:"w-11 h-6",thumb:"h-4 w-4",translate:"translate-x-5",offset:"translate-x-1"};return t.jsx("button",{type:"button",role:"switch","aria-checked":n,disabled:o,onClick:()=>!o&&a(!n),className:`
        relative inline-flex flex-shrink-0 ${r.track} items-center rounded-full
        transition-colors duration-200 ease-in-out
        focus:outline-none focus:ring-2 focus:ring-offset-2 ${e.ring}
        ${n?e.on:"bg-gray-300"}
        ${o?"opacity-50 cursor-not-allowed":"cursor-pointer"}
      `,children:t.jsx("span",{className:`
          inline-block ${r.thumb} rounded-full bg-white shadow-md
          transform transition-transform duration-200 ease-in-out
          ${n?r.translate:r.offset}
        `})})}export{u as T};
