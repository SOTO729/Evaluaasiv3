import{d as a}from"./index-Dv0aPVCL.js";const r={getDashboard:async()=>(await a.get("/users/me/dashboard")).data};export{r as d};
