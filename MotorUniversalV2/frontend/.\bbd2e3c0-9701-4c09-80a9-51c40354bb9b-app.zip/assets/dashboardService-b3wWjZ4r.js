import{d as a}from"./index-D4tnsb06.js";const r={getDashboard:async()=>(await a.get("/users/me/dashboard")).data};export{r as d};
