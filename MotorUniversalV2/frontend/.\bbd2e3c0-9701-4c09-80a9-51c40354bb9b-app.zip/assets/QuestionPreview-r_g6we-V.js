import{r as l,j as e}from"./query-vendor-DOOuirZA.js";const d=({questionText:o,className:t=""})=>{const[s,n]=l.useState(!0),r=o.replace(/<[^>]*>/g,""),i=r.length>100||o.includes("<");return e.jsxs("div",{className:`card ${t}`,children:[e.jsxs("div",{className:"flex items-start",children:[e.jsx("div",{className:"flex-shrink-0 w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center fluid-mr-4",children:e.jsx("svg",{className:"fluid-icon-lg text-blue-600",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"})})}),e.jsxs("div",{className:"flex-1",children:[e.jsxs("div",{className:"flex items-center justify-between fluid-mb-2",children:[e.jsx("h3",{className:"fluid-text-sm font-medium text-gray-500",children:"Pregunta:"}),i&&e.jsx("button",{onClick:()=>n(!s),className:"fluid-text-xs text-primary-600 hover:text-primary-700 font-medium flex items-center fluid-gap-1",children:s?e.jsxs(e.Fragment,{children:["Mostrar menos",e.jsx("svg",{className:"fluid-icon-xs",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M5 15l7-7 7 7"})})]}):e.jsxs(e.Fragment,{children:["Ver completa",e.jsx("svg",{className:"fluid-icon-xs",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M19 9l-7 7-7-7"})})]})})]}),s?e.jsx("div",{className:"prose prose-sm max-w-none text-gray-900",dangerouslySetInnerHTML:{__html:o}}):e.jsx("p",{className:"fluid-text-lg font-medium text-gray-900",children:r.length>100?`${r.substring(0,100)}...`:r})]})]}),e.jsx("style",{children:`
        .prose h1 { font-size: 1.5em; font-weight: bold; margin: 0.5em 0; }
        .prose h2 { font-size: 1.3em; font-weight: bold; margin: 0.5em 0; }
        .prose h3 { font-size: 1.1em; font-weight: bold; margin: 0.5em 0; }
        .prose p { margin: 0.5em 0; line-height: 1.6; }
        .prose ul, .prose ol { margin: 0.5em 0; padding-left: 1.5em; }
        .prose li { margin: 0.25em 0; }
        .prose strong { font-weight: 600; }
        .prose em { font-style: italic; }
        .prose a { color: #2563eb; text-decoration: underline; }
        .prose img { max-width: 100%; height: auto; margin: 1em 0; border-radius: 0.5rem; }
        .prose table { width: 100%; border-collapse: collapse; margin: 1em 0; }
        .prose th, .prose td { border: 1px solid #e5e7eb; padding: 0.5em; }
        .prose th { background-color: #f3f4f6; font-weight: 600; }
        .prose blockquote { border-left: 4px solid #e5e7eb; padding-left: 1em; margin: 1em 0; color: #6b7280; }
        .prose code { background-color: #f3f4f6; padding: 0.2em 0.4em; border-radius: 0.25rem; font-family: monospace; font-size: 0.9em; }
        .prose pre { background-color: #1f2937; color: #f3f4f6; padding: 1em; border-radius: 0.5rem; overflow-x: auto; }
        .prose pre code { background-color: transparent; padding: 0; }
      `})]})};export{d as Q};
