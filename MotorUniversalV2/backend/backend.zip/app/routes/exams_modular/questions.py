"""
Preguntas y Respuestas - Módulo stub para migración gradual

Este archivo está preparado para la migración gradual desde exams.py
Por ahora, las rutas permanecen en el archivo original.

TODO: Migrar las siguientes funciones:
- get_question_types()
- get_questions()
- create_question()
- update_question()
- delete_question()
- get_answers()
- create_answer()
- update_answer()
- delete_answer()
"""
# Las rutas permanecen en el módulo principal por ahora
