"""
Utilidades de Cache para escalabilidad
"""
from functools import wraps
from flask import request
from app import cache
import hashlib
import json


def make_cache_key(*args, **kwargs):
    """
    Genera una clave de cache única basada en la ruta y parámetros de la request
    """
    path = request.path
    args_as_sorted_tuple = tuple(sorted(request.args.items()))
    
    # Crear hash de los argumentos para keys más cortas
    args_hash = hashlib.md5(
        json.dumps(args_as_sorted_tuple, sort_keys=True).encode()
    ).hexdigest()[:12]
    
    return f"{path}:{args_hash}"


def make_cache_key_with_user(*args, **kwargs):
    """
    Genera una clave de cache que incluye el ID del usuario
    """
    from flask_jwt_extended import get_jwt_identity
    
    try:
        user_id = get_jwt_identity()
    except:
        user_id = 'anon'
    
    path = request.path
    args_as_sorted_tuple = tuple(sorted(request.args.items()))
    
    args_hash = hashlib.md5(
        json.dumps(args_as_sorted_tuple, sort_keys=True).encode()
    ).hexdigest()[:12]
    
    return f"{path}:{user_id}:{args_hash}"


def cached_with_user(timeout=300):
    """
    Decorador para cachear respuestas incluyendo el usuario en la clave
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            cache_key = make_cache_key_with_user()
            
            # Intentar obtener del cache
            cached_response = cache.get(cache_key)
            if cached_response is not None:
                return cached_response
            
            # Ejecutar la función y cachear el resultado
            response = f(*args, **kwargs)
            cache.set(cache_key, response, timeout=timeout)
            
            return response
        return decorated_function
    return decorator


def invalidate_cache_pattern(pattern):
    """
    Invalida todas las claves de cache que coincidan con un patrón
    Útil cuando se modifica un recurso
    """
    try:
        # Obtener cliente Redis del cache
        redis_client = cache.cache._read_clients[0]
        
        # Buscar claves que coincidan con el patrón
        keys = redis_client.keys(f"flask_cache_{pattern}*")
        
        if keys:
            redis_client.delete(*keys)
            return len(keys)
        return 0
    except Exception as e:
        # Si Redis no está disponible, ignorar silenciosamente
        print(f"Warning: Could not invalidate cache pattern {pattern}: {e}")
        return 0


def invalidate_exams_cache():
    """Invalida todo el cache relacionado con exámenes"""
    return invalidate_cache_pattern("/api/exams")


def invalidate_standards_cache():
    """Invalida todo el cache relacionado con estándares"""
    return invalidate_cache_pattern("/api/competency-standards")


def invalidate_study_contents_cache():
    """Invalida todo el cache relacionado con materiales de estudio"""
    return invalidate_cache_pattern("/api/study-contents")


# Cache keys para recursos específicos
def get_exam_cache_key(exam_id):
    return f"exam:{exam_id}"


def get_standard_cache_key(standard_id):
    return f"standard:{standard_id}"


def get_user_dashboard_cache_key(user_id):
    return f"dashboard:{user_id}"
