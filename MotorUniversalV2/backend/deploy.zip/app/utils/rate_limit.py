"""
Rate Limiting utilities para proteger endpoints sensibles
"""
from functools import wraps
from flask import request, jsonify
from app import cache
import time


def get_client_ip():
    """Obtener IP del cliente, considerando proxies"""
    if request.headers.get('X-Forwarded-For'):
        return request.headers.get('X-Forwarded-For').split(',')[0].strip()
    if request.headers.get('X-Real-IP'):
        return request.headers.get('X-Real-IP')
    return request.remote_addr or 'unknown'


def rate_limit(limit=10, window=60, key_prefix='rl'):
    """
    Decorador para limitar la tasa de requests
    
    Args:
        limit: Número máximo de requests permitidas
        window: Ventana de tiempo en segundos
        key_prefix: Prefijo para la clave de cache
    
    Returns:
        429 Too Many Requests si se excede el límite
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            client_ip = get_client_ip()
            endpoint = request.endpoint or 'unknown'
            
            # Crear clave única para este cliente y endpoint
            cache_key = f"{key_prefix}:{endpoint}:{client_ip}"
            
            try:
                # Obtener contador actual
                current = cache.get(cache_key)
                
                if current is None:
                    # Primera request - inicializar contador
                    cache.set(cache_key, 1, timeout=window)
                    current = 1
                elif current >= limit:
                    # Límite excedido
                    return jsonify({
                        'error': 'Too Many Requests',
                        'message': f'Límite de {limit} requests por {window} segundos excedido. Intenta más tarde.',
                        'retry_after': window
                    }), 429
                else:
                    # Incrementar contador
                    cache.set(cache_key, current + 1, timeout=window)
                    current += 1
                
                # Agregar headers de rate limit a la respuesta
                response = f(*args, **kwargs)
                
                # Si la respuesta es una tupla (jsonify, status_code)
                if isinstance(response, tuple):
                    resp_data, status_code = response[0], response[1] if len(response) > 1 else 200
                    # No podemos modificar headers fácilmente aquí, pero lo dejamos para el middleware
                    return response
                
                return response
                
            except Exception as e:
                # Si Redis no está disponible, permitir la request
                print(f"Rate limit warning: {e}")
                return f(*args, **kwargs)
        
        return decorated_function
    return decorator


def rate_limit_login(limit=5, window=300):
    """
    Rate limiting específico para login
    Más estricto: 5 intentos cada 5 minutos por IP
    """
    return rate_limit(limit=limit, window=window, key_prefix='rl_login')


def rate_limit_register(limit=3, window=3600):
    """
    Rate limiting específico para registro
    Muy estricto: 3 registros por hora por IP
    """
    return rate_limit(limit=limit, window=window, key_prefix='rl_register')


def rate_limit_password_reset(limit=3, window=3600):
    """
    Rate limiting para reset de contraseña
    3 intentos por hora por IP
    """
    return rate_limit(limit=limit, window=window, key_prefix='rl_pwreset')


def rate_limit_api(limit=100, window=60):
    """
    Rate limiting general para API
    100 requests por minuto por IP
    """
    return rate_limit(limit=limit, window=window, key_prefix='rl_api')
