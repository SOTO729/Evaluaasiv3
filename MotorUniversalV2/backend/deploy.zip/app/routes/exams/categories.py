"""
Categorías y Temas - Módulo stub para migración gradual

Este archivo está preparado para la migración gradual desde exams.py
Por ahora, las rutas permanecen en el archivo original.

TODO: Migrar las siguientes funciones:
- get_categories()
- create_category()
- update_category()
- delete_category()
- get_topics()
- create_topic()
- update_topic()
- delete_topic()
"""
# Las rutas permanecen en el módulo principal por ahora
