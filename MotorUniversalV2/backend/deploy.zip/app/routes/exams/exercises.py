"""
Ejercicios Interactivos - Módulo stub para migración gradual

Este archivo está preparado para la migración gradual desde exams.py
Por ahora, las rutas permanecen en el archivo original.

TODO: Migrar las siguientes funciones:
- get_topic_exercises()
- create_exercise()
- update_exercise()
- delete_exercise()
- get_exercise_details()
- get_exercise_steps()
- create_exercise_step()
- update_step()
- delete_step()
- get_step_actions()
- create_step_action()
- update_action()
- delete_action()
- upload_step_image()
"""
# Las rutas permanecen en el módulo principal por ahora
